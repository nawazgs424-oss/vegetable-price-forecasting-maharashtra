# AGMARKNET Maharashtra Onion and Tomato Daily Mandi Prices, 2010-2026

This dataset was downloaded from the AGMARKNET 2.0 public API maintained by the Directorate of Marketing & Inspection, Ministry of Agriculture and Farmers Welfare, Government of India.

Scope:
- State: Maharashtra
- Commodities: Onion and Tomato
- Period: January 2010 through August 2026
- August 2026 is partial because the download was performed during August 2026.
- Unit of arrivals: metric tonnes
- Unit of prices: Indian rupees per quintal

Suggested paper title:
“Short-Term Forecasting of Onion and Tomato Prices in Maharashtra Mandis Using AGMARKNET Daily Data, 2010-2026”

Important columns:
- `date`
- `commodity`
- `market`
- `variety`
- `arrivals_metric_tonnes`
- `minimum_price_rs_per_quintal`
- `maximum_price_rs_per_quintal`
- `modal_price_rs_per_quintal`

For time-series modelling, use `modal_price_rs_per_quintal` as the main price variable. Aggregate by `date` and `commodity` using mean, median, or arrival-weighted average before fitting ARIMA/SARIMA/Prophet/XGBoost/LSTM models.

Rows downloaded: 337213
Failed monthly requests: 0

Fit-ready file:
- `agmarknet_maharashtra_onion_tomato_fit_ready_daily_timeseries_2010_2026.csv` aggregates raw mandi/variety rows to daily commodity-level time series. Use `modal_price_arrival_weighted_rs_per_quintal` as the primary target variable. `observed=0` marks calendar dates with no returned mandi observations.
